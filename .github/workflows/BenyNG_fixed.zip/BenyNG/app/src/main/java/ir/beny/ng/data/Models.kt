package ir.beny.ng.data

data class Server(
    val id: String,
    val name: String,
    val protocol: String,
    val host: String,
    val port: Int,
    val raw: String,
    val group: String = "",
)

data class Sub(val id: String, val name: String, val url: String)

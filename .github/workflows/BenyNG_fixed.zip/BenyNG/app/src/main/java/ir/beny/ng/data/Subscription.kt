package ir.beny.ng.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

object Subscription {
    suspend fun fetch(url: String): String = withContext(Dispatchers.IO) {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 15000
            c.readTimeout = 20000
            c.setRequestProperty("User-Agent", "BenyNG/0.1")
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    fun parse(body: String): List<Server> {
        var links = LinkParser.extractLinks(body)
        if (links.isEmpty()) {
            val decoded = try {
                String(LinkParser.decodeB64(body))
            } catch (e: Exception) {
                ""
            }
            links = LinkParser.extractLinks(decoded)
        }
        return links.mapNotNull { LinkParser.parse(it) }.distinctBy { it.id }
    }
}

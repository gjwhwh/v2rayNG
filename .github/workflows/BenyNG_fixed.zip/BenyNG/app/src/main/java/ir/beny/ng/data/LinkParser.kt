package ir.beny.ng.data

import android.net.Uri
import android.util.Base64
import org.json.JSONObject
import java.util.UUID

object LinkParser {
    private val linkRegex = Regex("(?<![A-Za-z])(vmess|vless|trojan|ss)://[^\\s\"'<>]+")

    fun extractLinks(text: String): List<String> = linkRegex.findAll(text).map { it.value }.toList()

    fun decodeB64(s: String): ByteArray {
        var t = s.trim().replace('-', '+').replace('_', '/')
            .replace("\n", "").replace("\r", "").replace(" ", "")
        while (t.length % 4 != 0) t += "="
        return Base64.decode(t, Base64.DEFAULT)
    }

    fun parse(link: String): Server? = try {
        when {
            link.startsWith("vmess://") -> vmess(link)
            link.startsWith("vless://") || link.startsWith("trojan://") -> urlStyle(link)
            link.startsWith("ss://") -> shadowsocks(link)
            else -> null
        }
    } catch (e: Exception) {
        null
    }

    private fun vmess(link: String): Server? {
        val j = JSONObject(String(decodeB64(link.removePrefix("vmess://"))))
        val host = j.optString("add")
        val port = j.optString("port").toIntOrNull() ?: return null
        if (host.isBlank()) return null
        return make("vmess", j.optString("ps"), host, port, link)
    }

    private fun urlStyle(link: String): Server? {
        val proto = link.substringBefore("://")
        val afterScheme = link.substringAfter("://")
        val name = if ('#' in afterScheme) Uri.decode(afterScheme.substringAfter('#')) else ""
        val core = afterScheme.substringBefore('#').substringBefore('?').substringBefore('/')
        val hp = core.substringAfterLast('@')
        val (host, port) = splitHostPort(hp) ?: return null
        return make(proto, name, host, port, link)
    }

    private fun shadowsocks(link: String): Server? {
        var rest = link.removePrefix("ss://")
        val name = if ('#' in rest) Uri.decode(rest.substringAfter('#')) else ""
        rest = rest.substringBefore('#').substringBefore('?').trimEnd('/')
        val hp = if ('@' in rest) rest.substringAfterLast('@')
        else String(decodeB64(rest)).substringAfterLast('@')
        val (host, port) = splitHostPort(hp.substringBefore('/')) ?: return null
        return make("ss", name, host, port, link)
    }

    private fun splitHostPort(s: String): Pair<String, Int>? {
        val t = s.trim()
        if (t.startsWith("[")) {
            val end = t.indexOf(']')
            if (end < 0) return null
            val port = t.substring(end + 1).removePrefix(":").toIntOrNull() ?: return null
            return t.substring(1, end) to port
        }
        val i = t.lastIndexOf(':')
        if (i <= 0) return null
        val port = t.substring(i + 1).toIntOrNull() ?: return null
        return t.substring(0, i) to port
    }

    private fun make(proto: String, name: String, host: String, port: Int, raw: String): Server =
        Server(
            UUID.nameUUIDFromBytes(raw.toByteArray()).toString(),
            name.ifBlank { "$host:$port" }, proto, host, port, raw,
        )
}

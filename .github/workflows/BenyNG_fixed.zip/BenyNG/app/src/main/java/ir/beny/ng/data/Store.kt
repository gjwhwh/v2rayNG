package ir.beny.ng.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("beny_ng", Context.MODE_PRIVATE)

    var selectedId: String?
        get() = p.getString("sel", null)
        set(v) = p.edit().putString("sel", v).apply()
    var autoSelect: Boolean
        get() = p.getBoolean("auto", true)
        set(v) = p.edit().putBoolean("auto", v).apply()
    var lastClip: String
        get() = p.getString("clip", "")!!
        set(v) = p.edit().putString("clip", v).apply()

    fun loadServers(): List<Server> = try {
        val a = JSONArray(p.getString("servers", "[]"))
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Server(
                o.getString("id"), o.getString("name"), o.getString("protocol"),
                o.getString("host"), o.getInt("port"), o.getString("raw"), o.optString("group"),
            )
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun saveServers(list: List<Server>) {
        val a = JSONArray()
        list.forEach {
            a.put(
                JSONObject().put("id", it.id).put("name", it.name).put("protocol", it.protocol)
                    .put("host", it.host).put("port", it.port).put("raw", it.raw).put("group", it.group)
            )
        }
        p.edit().putString("servers", a.toString()).apply()
    }

    fun loadSubs(): List<Sub> = try {
        val a = JSONArray(p.getString("subs", "[]"))
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Sub(o.getString("id"), o.getString("name"), o.getString("url"))
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun saveSubs(list: List<Sub>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("url", it.url)) }
        p.edit().putString("subs", a.toString()).apply()
    }
}

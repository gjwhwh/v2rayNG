# BenyNG – اصلاحات

- تنظیم Gradle Wrapper properties برای Gradle 8.10.2 اضافه شد.
- هنگام حذف/جایگزینی سرورها، `selectedId` در SharedPreferences هم همگام می‌شود.
- توجه: تابع `connect()` در نسخه فعلی فقط پیام نمایش می‌دهد و VPN واقعی را راه‌اندازی نمی‌کند.
  برای اتصال واقعی باید `VpnService` و هسته پروکسی (مثل Xray/sing-box) به پروژه اضافه و به کانفیگ‌ها متصل شود.
